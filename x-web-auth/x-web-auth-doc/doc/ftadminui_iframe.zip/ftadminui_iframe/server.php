<?php

	$arr=array(
            array('id'=>'1','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$63'),
			array('id'=>'2','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$64'),
			array('id'=>'3','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$65'),
			array('id'=>'4','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$65'),
			array('id'=>'5','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$65'),
			array('id'=>'6','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$65'),
			array('id'=>'7','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$65'),
			array('id'=>'8','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$65'),
			array('id'=>'9','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$65'),
			array('id'=>'10','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$65'),

			array('id'=>'11','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$65'),
			array('id'=>'12','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$63'),
			array('id'=>'13','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$64'),
			array('id'=>'14','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$65'),
			array('id'=>'15','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$65'),
			array('id'=>'16','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$65'),
			array('id'=>'17','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$65'),
			array('id'=>'18','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$65'),
			array('id'=>'19','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$65'),
			array('id'=>'20','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$65'),
			array('id'=>'21','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$65'),
			array('id'=>'22','name'=>'审批','title'=>'飞天素材网','desc'=>'专业提供网站源码、模板下载的网站','price'=>'$65'),
         );

	echo json_encode($arr,true);exit;
	//echo json_encode($data,JSON_UNESCAPED_UNICODE);exit;